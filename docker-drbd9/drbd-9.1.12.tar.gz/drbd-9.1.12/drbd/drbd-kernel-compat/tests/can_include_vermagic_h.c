/* { "version": "v5.7-rc2", "commit": "51161bfc66a68d21f13d15a689b3ea7980457790", "comment": "An include guard was added to vermagic.h, forbidding modules from including it", "author": "Leon Romanovsky <leonro@mellanox.com>", "date": "Sun Apr 19 18:55:06 2020 +0300" } */

#include <linux/vermagic.h>
